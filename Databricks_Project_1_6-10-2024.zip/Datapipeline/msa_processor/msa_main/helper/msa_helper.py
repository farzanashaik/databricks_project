import json
from msa_main.utils.sparksessioncreate import CreateSparkSession
from msa_main.helper.ingest import Ingest
from msa_main.helper.transform import Transform
from msa_main.helper.persist import Persist


class MSAHelper:
    def __init__(self, conf):
        self.conf = conf

    def start_pipeline(self, args, run_id):
        self.spark = CreateSparkSession.create_spark_session()
        self.scope = self.conf.get('AZURE_KEYVAULT_CONFIGS', 'scope')
        input_file_path = json.loads(args.ms_payload).get('payload').get("input_file_path")
        receipe_filter = json.loads(args.ms_payload).get('payload').get("receipe")
        uc_tablename = self.conf.get('UNITY_CATALOG', 'table')

        self.storage_account_name = dbutils.secrets.get(self.scope, self.conf.get('STORAGE_ACCOUNT', 'sa_name'))
        self.storage_account_key = dbutils.secrets.get(self.scope, self.conf.get('STORAGE_ACCOUNT', 'sa_key'))

        ingest = Ingest(self.spark)
        input_df = ingest.read_file(input_file_path)

        transform = Transform(self.spark)
        transform_df = transform.transform_data(input_df, receipe_filter, run_id)

        persist = Persist(self.spark)
        persist.persist_data(transform_df, uc_tablename)


