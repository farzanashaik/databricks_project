import logging
import logging.config

class Persist:
    def __init__(self,spark):
        self.spark = spark

    def persist_data(self,df, table_name):
        """
        saving data ot unity catalog table
        """
        try:
            df.write.format("delta").mode("overwrite").saveAsTable(table_name)
        except Exception as exp:
            raise Exception(str(exp))
