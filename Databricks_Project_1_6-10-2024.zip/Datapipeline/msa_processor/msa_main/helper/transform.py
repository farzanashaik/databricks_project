from pyspark.sql.types import FloatType
from pyspark.sql.functions import when, lit, col, ceil
from msa_main.helper.convert_duration import get_mins
from pyspark.sql import functions as F
import logging
import logging.config


class Transform:
    def __init__(self, spark):
        self.spark = spark

    def apply_rule1(self, df):
        # rules
        pass

    def apply_rule2(self, df):
        pass

    def transform_data(self, df, filter_receipe, run_id):
        try:
            receipe_df = df.filter(F.lower(df.ingredients).contains(filter_receipe))

            receipe_df = receipe_df.withColumn('cookTime', when(F.col('cookTime') == "", "PT").otherwise(col('cookTime')))
            receipe_df = receipe_df.withColumn('prepTime', when(F.col('prepTime') == "", "PT").otherwise(col('prepTime')))

            convertduration = F.udf(lambda duration: get_mins(duration), FloatType())

            receipe_df_mins = receipe_df.withColumn("cookTime_mins", convertduration(col("cookTime"))) \
                .withColumn("prepTime_mins", convertduration(col("prepTime")))

            receipe_total_cook_time = receipe_df_mins.withColumn("total_cook_time",
                                                                 col("prepTime_mins") + col("cookTime_mins"))
            receipe_difficulty = receipe_total_cook_time.withColumn("difficulty", \
                                                                    when((receipe_total_cook_time.total_cook_time < 30),
                                                                         lit("easy")) \
                                                                    .when(
                                                                        (receipe_total_cook_time.total_cook_time >= 30) \
                                                                        & (
                                                                                    receipe_total_cook_time.total_cook_time <= 60), \
                                                                        lit("medium")) \
                                                                    .otherwise(lit("hard")))
            receipe_difficulty_avg_level = receipe_difficulty.groupBy("difficulty").avg(
                "total_cook_time").withColumnRenamed('avg(total_cook_time)',
                                                     'avg_total_cooking_time')

            receipe_difficulty_avg_level_df = receipe_difficulty_avg_level.select('difficulty',
                                                                               ceil('avg_total_cooking_time').alias(
                                                                                   'avg_total_cooking_time'))

            receipe_difficulty_avg_level_df = receipe_difficulty_avg_level_df.witCOlumn('run_id', F.lit(run_id))

            return receipe_difficulty_avg_level_df
        except Exception as exp:
            raise str(exp)