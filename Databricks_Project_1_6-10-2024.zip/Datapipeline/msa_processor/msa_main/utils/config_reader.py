import os
import configparser
from pathlib import Path
import msa_main

class ConfigReader():
    def __init__(self):
        self.config = configparser.ConfigParser()
        config_dir = os.path.join(Path(msa_main.__file__).parents[0], 'config')

        if os.environ['env'] == 'dev':
            config_path = os.path.join(config_dir, 'msa_dev.conf')
        elif os.environ['env'] == 'sqa':
            config_path = os.path.join(config_dir, 'msa_sqa.conf')
        elif os.environ['env'] == 'prod':
            config_path = os.path.join(config_dir, 'msa_prod.conf')
        else:
            config_path = os.path.join(config_dir, 'msa_dev.conf')
        self.config.read(config_path)