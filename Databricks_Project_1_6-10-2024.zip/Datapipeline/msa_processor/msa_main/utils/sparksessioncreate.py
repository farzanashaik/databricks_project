import os

from pyspark.sql import SparkSession

class CreateSparkSession:
    def __init__(self):
        self.spark = None

    @staticmethod
    def create_spark_session():
        if os.getenv('REMOTE'):
            from databricks.connect import DatabricksSession
            spark = DatabricksSession.builder.getOrCreate()
        else:
            spark = SparkSession.builder.getOrCreate()

        return spark
