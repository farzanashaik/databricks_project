import os

def build_wheel():
    try:
        microservices = ['msa_processor',
              'msb_processor']

        for microservice in microservices:
            os.chdir(microservice)
            os.system(
                "python setup.py bdist_wheel"
            )
            os.chdir('../')
    except Exception as e:
        print(e)

if __name__ == '__main__':
    build_wheel()