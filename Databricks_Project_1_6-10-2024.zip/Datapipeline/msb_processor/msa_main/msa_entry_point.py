import os
import uuid
import argparse
import json

from msa_main.utils.config_reader import ConfigReader
from msa_main.helper.msa_helper import MSAHelper

parser = argparse.ArgumentParser()
parser.add_argument('--ms_payload', '--ms_payload', type=str, required=True, help="micro service payload")
args = parser.parse_args()

"""
--ms_payload "{\"payload\":{\"run_id\":\"99e8e203-4180-40ed-8fb2-9bf384fbcf2e\", \"input_file_path\":\"abfss://raw@bootcampsadev.dfs.core.windows.net/recipes-000.json\", \"receipe\":\"paneer\"}}"
"""

def entry_point():
    conf = (ConfigReader()).config
    run_id = json.loads(args.ms_payload).get('payload').get("run_id")

    mshelper = MSAHelper(conf)
    mshelper.start_pipeline(args, run_id)


# entry_point()