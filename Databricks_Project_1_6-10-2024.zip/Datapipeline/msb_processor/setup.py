from setuptools import setup, find_packages

def requirements_txt():
    with open('requirements.txt', 'r') as f:
        required = f.read().splitlines()
    return required

setup(
    name='msb',
    author_email='contact@raxicube.com',
    description='MS A Micro service',
    package_dir={
        'msa_main': 'msa_main',
        'common_utils': '../common_utils'
    },
    packages=find_packages() + ['common_utils'],
    install_requires=requirements_txt(),
    entry_points={
        'group_1': 'msa_processor=msa_main.msa_entry_point:entry_point'
    },
    include_package_data=True
)