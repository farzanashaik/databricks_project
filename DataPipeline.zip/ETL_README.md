# Data Engineering Test etl_readme
### Author: Ram

This document is designed to be read in parallel with the code in the `Datapipeline` repository. This document addresses the following topics:
- ETL Project Structure;
- ETL Code explanation;
- Data quality checks (like input/output dataset validation).;
- Execute code;
- Packaging the code;
- spark-submit from zip file;
- Implement CI/CD for this application;
- Diagnose and tune the application in case of performance problems;
- Schedule this pipeline to run periodically;

## ETL Project Structure
The basic project structure is as follows:
```bash
root/
 |-- dist/
 |   |-- pipelines-0.0.1.tar.gz
 |-- pipeline/
 |   |-- helper/
 |   |-- | -- __init__.py
 |   |-- | -- convert_duration.py
 |   |-- | -- ingest.py
 |   |-- | -- persist.py
 |   |-- | -- transform.py
 |   |-- utils/
 |   |-- | -- __init__.py
 |   |-- | -- configreader.py
 |   |-- | -- sparkconfcreate.py
 |-- resources/
 |   |-- configs/
 |   |-- | -- logging.conf
 |   |-- | -- pipeline_dev.ini
 |   |-- input/
 |   |-- output/
 |-- test/
 |   |-- data/
 |   |-- | -- non_beef_items.json
 |   |-- | -- test_time.json
 |   |-- __init__.py
 |   |-- test_transform.py
 |   |-- test_udf.py
 |   ETL_README.md
 |   main.py
 |   MANIFEST.in
 |   README.md
 |	 requirements.txt
 |	 setup.py
 ```

## ETL code explanation
The `main` Python module containing the ETL job (which will be sent to the Spark cluster), is in project's root names `main.py`. Any external configuration parameters required by main.py are stored in project's root directory `resources/configs/pipeline.ini` and `resources/configs/logging.conf` for logging. Additional modules that support this job can be kept in the `pipeline` folder.
Also `main` method takes four command line arguments for `input and output file location`, and `config` files such as `pipeline.ini' and 'logging.conf`

`ingest.py` in `pipeline/helper` directory is for reading input json files and rerurns dataframe of all input records.
All transformation logic is inside `transform.py`, such as replacing null values, filtering ingrediens `beef`, converting duration, caluclating total cooktime, adding difficulty column and creating final dataframe with required columns by caluclating average total cooking time.
in input data `cookTime` and `prepTime` fields are in  `iso8601` format (ex: `PT1H15M`). `transformation.py` used other helper script `convert_duration.py` as udf for converting `iso8601` time format to seconds and minutes. To do this task one python library available i.e `isodate`.

`persist.py` is just for saving the final dataframe to desired format (`csv in this case`).

`sparkconfcreate.py` is for creating spark context which can be used across the project.
`configreader.py` is for parsing `pipeline.ini` file which has pipeline parameters.

All the input files and conf files are in `resources` directory. output also being stored here. I am using custom log handler for logging the status in different modules.
All `exceptions` have been handled in each module with `try`, `catch` and `raise` blocks.

unittesting of the etl code is in test directory in project's root directory. Same test data is in `data` directory. 
Test cases has been written to test transform module. 
- `test_transform.py`: If input data does not have beef as ingredient at all, there should not be any records in final dataframe;
                       Final dataframe should have two colums such as `difficulty` and `avg_total_cooking_time`.
                       Final dataframe should have only two colums. column count also checked.
- `test_ingest.py`: This test case checks if input data loaded correctly and validate colum count. Also checks for mandatory columns such as `prepTime`,`cookTime`,`ingredients` exists in loaded dataframe or not.
- `test_udf.py`: Checks it is able to convert the ISO8601 date accurately or not;

`setyp.py` is for packaging the code as zip which includes all required packages, and external dependencies, python version...

`MANIFEST.in` for including non-python files to zip package.

`requirements.txt` for lising all external dependent libraries.

## Execute code locally :
Make sure local environment has been set up properly. This project has developed in Pycharm IDE. 
Software versions used in this project for Developing and testing locally:
- OS: Windows 10
- Python 3.7.0
- spark 3.0.2 for hadoop 2.7
- JDK 1.8
- Pycharm Community Edition 2020.2
- winutils for hadoop 2.7

```bash
spark-submit --master local main.py --loggingconf resources/configs/logging.conf  --pipelineini resources/configs/pipeline_dev.ini --input resources/input/ --output resources/output
```

## packaging the code
`python setup.py sdist`

## Test code with python build package (zip file)
- locate to dist directory and install pipelines package with pip.
`pip install pipelines-0.0.1.tar.gz`
- then execute below command. Output csv file will get saved in resources/output directory.
```bash
spark-submit --master local --py-files pipelines-0.0.1.tar.gz main.py --loggingconf resources/configs/logging.conf  --pipelineini resources/configs/pipeline_dev.ini --input resources/input/ --output resources/output
```
## Test in Google Cloud Dataproc 3 node cluster
This code has tested in 3 node Google cloud Dataproc cluster.
followed same process as windows.
- copy package and relevant scripts to Dataproc cluster master node
- pip install pipelines-0.0.1.tar.gz
Run spark-submit command
```bash
spark-submit --master spark://localhost:4040 --deploy-mode client --py-files pipelines-0.0.1.tar.gz main.py --loggingconf resources/configs/logging.conf  --pipelineini resources/configs/pipeline_dev.ini --input /user/pranalytics_online/input --output /user/pranalytics_online/output
```
Test run snapshot from Dataproc cluster:
![A test image](google_cloud.PNG)

## CI/CD Pipeline:
There are multiple ways to deloy this PySpark application in Production.
- Create CI/CD pipeline in Azure devops and deploy it to Azure Databricks (DBFS). install the package from DBFS. We can schedule the Spark job to to run periodically in Databricks.`(We are using Azure Devops and Databricks in our Project).`
- Create Docker image of our application and deploy it to Kubernetes cluster
- Use Jenkins to deploy and submit spark jobs in cluster

## schedule this pipeline to run periodically
- Apache `Airflow` to schedule to run periodically (Sample script attached, but not tested).
- `Databricks` scheduler if we are using Databricks platform.
- Apache `Oozie`
- `Cron` tab

##  diagnose and tune the application in case of performance problems
- Track the Spark application logs and understand which step is taking more time.
- I am using UDF here, UDFs are black box for spark, incase if transform step is taking more time, see if UDF is causing the delay. Implement the script without udf.
- YARN ResourceManager UI: this utility provides a deep view of cluster resources, such as memory and CPU resources for each executor.
- Spark Web UI: provides a deep dive into the tasks, the Spark configuration inside each task. One of the best features inside the Spark UI is its option to look into the execution plan and the Directed Acyclic Graph (DAG) that may also be used to visualize the task repartition in each stage.
- Basic log with log4j
- Adding custom metrics with Prometheus, Push gateway and Grafana
- Setting the configuration parameters correctly is very important and determines the source consumption and performance of Spark basically. 
  ```bash
  Ex: spark.driver.memory 5g
  spark.executor.memory 10g
  ```