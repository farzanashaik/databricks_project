import logging
import logging.config
import sys

class Ingest:
    def __init__(self,spark):
        self.spark = spark

    def read_json(self,input_location):
        logger = logging.getLogger("Ingest")
        try:
            logger.info("Ingesting json files from input directory")
            #print(input_location)
            df_receipes = self.spark.read.json(input_location)
            logger.info('Reading data Successful')
            return df_receipes
        except Exception as exp:
            logger.error("An error occured while reading input data > "+str(exp))
            raise OSError("input directory doesn't exists")
    def read_excel(self, input_location):
        pass
    def read_db(self):
        df = self.spark.read.format('jdbc').option('host', '127.0.0.1').option('username', 'xyz').option('password', '234234').option('dbtable', 'emp').load()
        return df
    def csv_reader(self, input_location, header, delimiter):
        df = self.spark.read.format('csv').option('inferSchema', True).option('header', header).option('delimiter', delimiter).load(input_location)
        return df
