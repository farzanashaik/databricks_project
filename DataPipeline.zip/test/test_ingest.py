import unittest
from pipeline.helper import ingest
from pipeline.utils import sparkconfcreate

sc = sparkconfcreate.SparkCreateSession()
spark = sc.create_spark_session()

class IngestTest(unittest.TestCase):
    def mock_extract(self):
        df_receipes = spark.read.json("test_data/non_beef_items.json")
        return df_receipes

    def test_ingest_count_columns(self):
        df = IngestTest.mock_extract(self)
        #df_receipes = spark.read.json("test_data/non_beef_items.json")
        ing = ingest.Ingest(spark)
        df_ingest = ing.ingest_data('test_data/non_beef_items.json')
        self.assertEqual(9,len(df_ingest.columns))
        self.assertTrue("cookTime" in df_ingest.columns)
        self.assertTrue("prepTime" in df_ingest.columns)
        self.assertTrue("ingredients" in df_ingest.columns)

if __name__ == '__main__':
    unittest.main()