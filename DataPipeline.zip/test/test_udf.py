import unittest
from pipeline.helper import convert_duration

class UDFTest(unittest.TestCase):
    def test_convert_duration(self):
        self.assertEqual(75.0, convert_duration.get_mins("PT1H15M"))
        with self.assertRaises(ValueError):
            convert_duration.get_mins("")
        self.assertEqual(0.0, convert_duration.get_mins("PT"))
        self.assertEqual(10.0, convert_duration.get_mins("PT10M"))

if __name__ == '__main__':
    unittest.main()