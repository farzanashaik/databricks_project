import unittest
from pipeline.utils import sparkconfcreate
from pipeline.helper import transform
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

class TransformTest(unittest.TestCase):
    def mock_extract(self):
        df_receipes = spark.read.json("test_data/non_beef_items.json")
        return df_receipes

    def test_transform(self):
        df = TransformTest.mock_extract(self)
        tf = transform.Transform(spark)
        df_transform = tf.transform_data(df,'beef')
        self.assertEqual(0,df_transform.count())
        self.assertTrue("difficulty" in df_transform.columns)
        self.assertTrue("avg_total_cooking_time" in df_transform.columns)
        self.assertEqual(2,len(df_transform.columns))

if __name__ == '__main__':
    unittest.main()
